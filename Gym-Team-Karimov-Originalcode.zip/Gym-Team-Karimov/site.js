'use strict';
const week = [
 {day:'Montag',short:'MO',courses:[['Wrestling','16:30','18:00'],['Boxen','18:00','19:30'],['MMA','19:30','21:00']]},
 {day:'Dienstag',short:'DI',courses:[['Grappling','16:30','18:00'],['Thaiboxen','18:00','19:30'],['Wrestling','19:30','21:00']]},
 {day:'Mittwoch',short:'MI',courses:[['Boxen','16:30','18:00'],['MMA','18:00','19:30'],['Grappling','19:30','21:00']]},
 {day:'Donnerstag',short:'DO',courses:[['Wrestling','16:30','18:00'],['Thaiboxen','18:00','19:30'],['Boxen','19:30','21:00']]},
 {day:'Freitag',short:'FR',courses:[['Grappling','16:30','18:00'],['MMA','18:00','19:30'],['Thaiboxen','19:30','21:00']]},
 {day:'Samstag',short:'SA',courses:[['Boxen','12:00','13:30'],['Wrestling','14:00','15:30'],['Grappling','16:00','17:30']]},
 {day:'Sonntag',short:'SO',courses:[['MMA','12:00','13:30'],['Frauentraining','15:30','17:00']]}
];
const adultPlans = [
 {name:'Limited 5',age:'AB 16 JAHREN',description:'5 Trainingseinheiten pro Monat.',prices:{24:79,12:99,6:119},defaultMonths:24},
 {name:'Limited 10',age:'AB 16 JAHREN',description:'10 Trainingseinheiten pro Monat.',prices:{24:99,12:119,6:139},defaultMonths:24},
 {name:'Unlimited',age:'AB 16 JAHREN',description:'Unbegrenztes Training.',prices:{24:119,12:139,6:159,3:169},defaultMonths:24}
];
const kidPlans = [
 {name:'Kids Unlimited',age:'6–10 JAHRE',description:'Unbegrenztes Training für Kinder.',prices:{12:89,6:109},defaultMonths:12},
 {name:'Jugendliche Limited 10',age:'11–15 JAHRE',description:'10 Trainingseinheiten pro Monat.',prices:{24:89,12:109,6:129},defaultMonths:24},
 {name:'Jugendliche Unlimited',age:'11–15 JAHRE',description:'Unbegrenztes Training für Jugendliche.',prices:{24:109,12:129,6:149},defaultMonths:24}
];
function renderWeek(filter='all') {
 const grid=document.getElementById('week-grid'); let count=0;
 grid.replaceChildren();
 week.forEach(({day,short,courses})=>{
  const column=document.createElement('section');column.className='day-column';column.setAttribute('aria-label',day);
  const heading=document.createElement('h4');heading.innerHTML=`<span aria-hidden="true">${short}</span><span class="day-name">${day}</span>`;column.append(heading);
  const list=document.createElement('ul');const selected=courses.filter(c=>filter==='all'||c[0]===filter);count+=selected.length;
  selected.forEach(([course,start,end])=>{const item=document.createElement('li');item.className='course-slot';item.innerHTML=`<strong>${course}</strong><span><time>${start}</time>–<time>${end}</time></span>`;list.append(item);});
  column.append(list);
  if(!selected.length){const empty=document.createElement('p');empty.className='no-course';empty.textContent='Kein Kurs';column.append(empty);}
  grid.append(column);
 });
 document.getElementById('schedule-count').textContent=`${count} ${count===1?'Einheit':'Einheiten'} pro Woche${filter==='all'?'':' · '+filter}`;
}
function renderPlans(category='adults') {
 const plans=category==='kids'?kidPlans:adultPlans;
 document.getElementById('category-note').textContent=category==='women'?'Für Frauen gelten dieselben Tarife wie für Erwachsene. Frauentraining: sonntags 15:30–17:00 Uhr.':category==='kids'?'Für Kinder von 6–10 Jahren und Jugendliche von 11–15 Jahren.':'Mitgliedschaften ab 16 Jahren.';
 const grid=document.getElementById('price-grid');grid.replaceChildren();
 plans.forEach((plan,index)=>{
  const id=`duration-${category}-${index}`;const card=document.createElement('article');card.className='price-card';
  card.innerHTML=`<span class="index">${plan.age}</span><h3>${plan.name}</h3><p>${plan.description}</p><p class="monthly-price" aria-live="polite"><strong>${plan.prices[plan.defaultMonths]} €</strong><span>pro Monat</span></p><label for="${id}">Laufzeit</label><select id="${id}" aria-label="Laufzeit für ${plan.name}">${Object.keys(plan.prices).map(Number).sort((a,b)=>b-a).map(months=>`<option value="${months}"${months===plan.defaultMonths?' selected':''}>${months} Monate</option>`).join('')}</select><p class="price-duration">${plan.defaultMonths} Monate · ${plan.prices[plan.defaultMonths]} € / Monat</p>`;
  card.querySelector('select').addEventListener('change',event=>{const months=Number(event.target.value);card.querySelector('.monthly-price strong').textContent=plan.prices[months]+' €';card.querySelector('.price-duration').textContent=`${months} Monate · ${plan.prices[months]} € / Monat`;});
  grid.append(card);
 });
 document.getElementById('membership-panel').setAttribute('aria-labelledby','tab-'+category);
}
const tabs=[...document.querySelectorAll('[role="tab"][data-category]')];
function selectTab(tab){tabs.forEach(t=>{const selected=t===tab;t.setAttribute('aria-selected',String(selected));t.tabIndex=selected?0:-1;});renderPlans(tab.dataset.category);}
tabs.forEach((tab,index)=>{tab.addEventListener('click',()=>selectTab(tab));tab.addEventListener('keydown',event=>{let next;if(event.key==='ArrowRight')next=(index+1)%tabs.length;if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;if(next!==undefined){event.preventDefault();selectTab(tabs[next]);tabs[next].focus();}});});
document.getElementById('course-filter').addEventListener('change',event=>renderWeek(event.target.value));
renderWeek();renderPlans();
