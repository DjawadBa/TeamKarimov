# Gym Team Karimov

Originaldateien aus dem Sites-Quellrepository, abgerufen am 17.11.2026.
Quellcommit: 7739e8d05fc97fbe553d371f9f3a1a63591c1ce1
Bestehende Webseite: https://gym-team-karimov.djawad-babakhani.chatgpt.site
Zur Weitergabe an GitHub-Nutzer stvdll.

## Dateien
- index.html: Seiteninhalt
- style.css: Gestaltung und responsive Darstellung
- site.js: Kursfilter und Mitgliedschaftstarife
- assets/: Bilder und Logo

Die Website-Dateien sind unverändert aus dem dist-Verzeichnis übernommen,
für die Übergabe lediglich in das Hauptverzeichnis verschoben.
Keine Installation und kein Build erforderlich. Keine Zugangsdaten enthalten.

## Lokal öffnen
index.html im Browser öffnen. Alternativ im entpackten Ordner:

    python3 -m http.server 8000

Dann http://localhost:8000 aufrufen.

## An GitHub übergeben
ZIP entpacken und den gesamten Inhalt inklusive assets in ein neues
GitHub-Repository übernehmen. Die ZIP selbst ist kein entpacktes Webprojekt.
Steve (stvdll) kann die Dateien in seinem eigenen Repository verwenden.
Eine Veröffentlichung auf GitHub ist durch dieses ZIP noch nicht erfolgt.

## Funktionsumfang
Statische Website mit Kursfilter und Tarifauswahl. Kein Backend,
keine Buchungsabwicklung und keine Online-Mitgliederregistrierung enthalten.
Änderungen in einer GitHub-Kopie aktualisieren die bestehende Sites-Webseite
nicht automatisch. Hosting und Domain der Kopie werden separat eingerichtet.
